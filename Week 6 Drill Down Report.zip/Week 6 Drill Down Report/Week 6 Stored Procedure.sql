USE AP

GO

CREATE OR ALTER PROCEDURE Extract_Data @Invoice_ID INT = NULL
AS
BEGIN

	SELECT *
	FROM Invoices i
	WHERE @Invoice_ID IS NULL OR i.InvoiceID = @Invoice_ID

END