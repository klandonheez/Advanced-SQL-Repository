USE AdventureWorks2022

CREATE TABLE Week5_SSIS_Import 
(Number1 decimal(10, 9),
 Currency char(3),
 [Date] datetime,
 Number2 decimal(10, 9))